## simulate two metacommunnity for independent project (codes from Shane)
# metacommunity 1: strong dispersal limitation, and broad niches 
# metacommunity 2: strong dispersal potential, and narrow niches

# Load libraries
library(tidyverse)
#devtools::install_github("plthompson/mcomsimr")
library(mcomsimr)

# number of patches
M <- 50

# total number of species
S <- 40

# model assumes exponential distance decay of dispersal, controlled by a rate parameter
# low values mean distance decay is weaker (==high connectivity)
d_low <- 1
d_high <- 0.05

# visual inspection (note that distances between patches will be determined by the landscape,
# which will differ from what we see here. This is a sanity check only to see that high and low
# connectivity differ)
plot(x = 1:M,
     y = exp(-d_high*(1:M)),
     ylim=c(0,1),
     col = 1, 
     type = 'b')

lines(x = 1:M,
      y = exp(-d_low*(1:M)),
      ylim=c(0,1),
      col = 2, 
      type = 'b')


# set up landscape (same for both metacommunities)
meta_landscape <- landscape_generate(patches = M)

# dispersal matrices for each treatment
disp_mat_high <- dispersal_matrix(landscape = meta_landscape,
                                  torus = TRUE,
                                  kernel_exp = d_high, 
                                  plot = TRUE)

disp_mat_low <- dispersal_matrix(landscape = meta_landscape,
                                 torus = TRUE,
                                 kernel_exp = d_low, 
                                 plot = TRUE)

# generate the time series of the environmental conditions for each patch (same for each treatment)
env_conditions <- env_generate(landscape = meta_landscape,
                               env1Scale = 50,
                               timesteps = 1000)

# density independent component of model
densInd_wide_nicheB <- env_traits(species = S, 
                            max_r = 5,                         # max growth rate
                            min_env = 0, max_env = 1,          # range of environment
                            env_niche_breadth = 0.5,       # niche breadth
                            optima_spacing = 'even')           # spacing of z_i (optima)

densInd_narrow_nicheB <- env_traits(species = S, 
                                  max_r = 5,                         # max growth rate
                                  min_env = 0, max_env = 1,          # range of environment
                                  env_niche_breadth = 0.2,       # niche breadth
                                  optima_spacing = 'even')           # spacing of z_i (optima)

# species interaction matrix
stabilising_interaction_mat <- species_int_mat(species = S,
                                         intra = 1,
                                         min_inter = 0,
                                         max_inter = 0.5)


## Simulate metacommunity dynamics

meta1 <- simulate_MC(patches=M, species=S, 
                        landscape = meta_landscape,
                        disp_mat = disp_mat_low, 
                        env.df = env_conditions, 
                        max_r = densInd_wide_nicheB$max_r, 
                        env_niche_breadth = densInd_wide_nicheB$env_niche_breadth,
                        env_optima = densInd_wide_nicheB$optima,
                        int_mat = stabilising_interaction_mat,
                        initialization=100, burn_in=100, timesteps=1)

meta2 <- simulate_MC(patches=M, species=S, 
                       landscape = meta_landscape,
                       disp_mat = disp_mat_high, 
                       env.df = env_conditions, 
                       max_r = densInd_narrow_nicheB$max_r, 
                       env_niche_breadth = densInd_narrow_nicheB$env_niche_breadth,
                       env_optima = densInd_narrow_nicheB$optima,
                       int_mat = stabilising_interaction_mat,
                       initialization=100, burn_in=100, timesteps=1)


## extract data

## metacommunity 1
# get the sites*species table at the time 1
meta1_comp <- meta1$dynamics.df %>% 
  as_tibble() %>%
  filter(time ==1) %>%
  dplyr::select(N, patch, species) %>%
  pivot_wider(names_from = species, names_prefix = "sp", values_from = N) %>%
  dplyr::select(- patch)

# as some species were absent at any sites, remove these species
meta1_comp <- meta1_comp[, colSums(meta1_comp) > 0]
  
# get the environment and spatial coordinates of each patch
meta1_env_xy <- meta1$dynamics.df %>% 
  as_tibble() %>%
  filter(time ==1) %>%
  distinct(patch, env) %>%
  bind_cols(meta1$landscape)


## metacommunity 2
# get the sites*species table at the time 1
meta2_comp <- meta2$dynamics.df %>% 
  as_tibble() %>%
  filter(time ==1) %>%
  dplyr::select(N, patch, species) %>%
  pivot_wider(names_from = species, names_prefix = "sp", values_from = N) %>%
  dplyr::select(- patch)

# as some species were absent at any sites, remove these species
meta2_comp <- meta2_comp[, colSums(meta2_comp) > 0]

# get the environment and spatial coordinates of each patch
meta2_env_xy <- meta2$dynamics.df %>% 
  as_tibble() %>%
  filter(time ==1) %>%
  distinct(patch, env) %>%
  bind_cols(meta2$landscape)


save(meta1_comp, meta1_env_xy, meta2_comp, meta2_env_xy, file = "Simulated_2metacommunities.RDATA")

